package com.sbitech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShiroRbacSystemApplication  {

    public static void main(String[] args) {
        SpringApplication.run(ShiroRbacSystemApplication.class, args);
    }

}
