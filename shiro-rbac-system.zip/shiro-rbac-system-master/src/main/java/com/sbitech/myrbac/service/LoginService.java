package com.sbitech.myrbac.service;

import com.sbitech.myrbac.vo.Resp;
import org.springframework.http.ResponseEntity;

/**
 * Created by EalenXie on 2019/3/26 16:23.
 * RBAC  基于角色的权限访问控制系统 服务说明
 */
public interface LoginService {


    /**
     * 用户登陆服务
     * 1 . 传入用户名/密码
     * 2 . Shiro 登陆校验 ,加载数据库中用户的角色，权限。
     *
     * @param username 传入的用户名
     * @param password 传入的密码(明文)
     */
    ResponseEntity<Resp> login(String username, String password);

    ResponseEntity<Resp> logout();
}
