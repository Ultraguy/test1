package com.sbitech.rbac.dao;

import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.RoleInfo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RoleMapper {
    @Select("SELECT * FROM roleInfo_view")
    List<RoleInfo> getAllRoles();

    @Select("SELECT * FROM role where role_name = #{roleName}")
    Role findByName(String roleName);

    @Insert("INSERT INTO role (role_name) VALUES (#{roleName})")
    void insert(Role role);

    @Delete("DELETE FROM role WHERE role_id = #{id}")
    void delete(int id);

    @Select("SELECT * FROM permission where permission_id in (select permission_id from role_permission where role_id = #{roleId})")
    List<Permission> getPermissionsByRole(Role role);


}
