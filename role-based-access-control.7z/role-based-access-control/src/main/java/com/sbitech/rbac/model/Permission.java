package com.sbitech.rbac.model;

public class Permission {
    private int permissionId;
    private String permissionName;
    private String pageUrl;

    public Permission() {
    }

    public Permission(int permissionId, String permissionName, String pageUrl) {
        this.permissionId = permissionId;
        this.permissionName = permissionName;
        this.pageUrl = pageUrl;
    }

    public int getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(int permissionId) {
        this.permissionId = permissionId;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public String getPageUrl() {
        return pageUrl;
    }

    public void setPageUrl(String pageUrl) {
        this.pageUrl = pageUrl;
    }
}
