package com.sbitech.rbac.model;

public class RoleInfo {
}
