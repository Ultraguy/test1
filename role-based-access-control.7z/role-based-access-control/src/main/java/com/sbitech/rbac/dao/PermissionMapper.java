package com.sbitech.rbac.dao;

import com.sbitech.rbac.dto.PermissionDTO;
import com.sbitech.rbac.model.Permission;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PermissionMapper {
    @Select("SELECT * FROM permission")
    List<Permission> getAllPermissions();

    @Select("SELECT * FROM permission WHERE permission_name like '%#{username}%'")
    Permission findByPermissionName(String name);

    @Insert("INSERT INTO permission (permission_name, page_url) VALUES (#{permissionName}, #{pageUrl})")
    void insert(PermissionDTO permission);

    @Delete("DELETE FROM permission WHERE permission_id = #{id}")
    void delete(int id);
}
