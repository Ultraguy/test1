package com.sbitech.rbac.dao;

import com.sbitech.rbac.model.RolePermission;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RolePermissionMapper {
    @Insert("INSERT INTO role_permission (role_id, permission_id) VALUES (#{roleId}, #{permissionId})")
    void insert(RolePermission rolePermission);

    @Delete("DELETE FROM role_permission WHERE role_id = #{roleId} and permission_id = #{permissionId}")
    void delete(RolePermission rolePermission);
}
