INSERT INTO user (user_id, username, password)
VALUES (1, 'admin', 'password1'),
       (2, '张三', 'password2'),
       (3, '李四', 'password3'),
       (4, '王五', 'password4'),
       (5, '赵六', 'password5'),
       (6, '田七', 'password6'),
       (7, '何八', 'password7');

INSERT INTO role (role_id, role_name)
VALUES (1, '系统管理员'),
       (2, '部长'),
       (3, '普通用户'),
       (4, '开发者'),
       (5, '测试人员');

INSERT INTO permission (permission_id, permission_name, page_url)
VALUES (1, '查看通用信息', '/dashboard'),
       (2, '查看公司机密信息', '/top-secret/'),
       (3, '查看开发部信息', '/department/development'),
       (4, '查看检证部信息', '/department/test'),
       (5, '编辑个人信息', '/profile/edit'),
       (6, '用户管理', '/users/manage'),
       (7, '权限管理', '/permissions/manage'),
       (8, '权限设置', '/permissions/setting'),
       (9, '角色管理', '/roles/manage');


INSERT INTO user_role (user_id, role_id)
VALUES (1, 1), -- admin -> 系统管理员
       (2, 2), -- 张三 -> 部长
       (3, 2), -- 李四 -> 部长
       (4, 3), -- 王五 -> 普通用户
       (5, 3), -- 赵六 -> 普通用户
       (2, 4), -- 张三兼任 -> 开发者
       (6, 4), -- 田七 -> 开发者
       (3, 5), -- 李四兼任 -> 测试人员
       (7, 4); -- 何八 -> 测试人员



INSERT INTO role_permission (role_id, permission_id)
VALUES (1, 1), -- 系统管理员 -> 查看通用信息
       (1, 6), -- 系统管理员 -> 用户管理
       (1, 7), -- 系统管理员 -> 权限管理
       (1, 8), -- 系统管理员 -> 权限设置
       (1, 9), -- 系统管理员 -> 角色管理
       (2, 1), -- 部长 -> 查看通用信息
       (2, 2), -- 部长 -> 查看公司机密信息
       (2, 5), -- 部长 -> 编辑个人信息
       (3, 1), -- 普通用户 -> 查看通用信息
       (3, 2), -- 普通用户 -> 编辑个人信息
       (4, 1), -- 开发者 -> 查看通用信息
       (4, 3), -- 开发者 -> 查看开发部信息
       (4, 5), -- 开发者 -> 编辑个人信息
       (5, 1), -- 测试人员 -> 查看通用信息
       (5, 4), -- 测试人员 -> 查看检证部信息
       (5, 5); -- 测试人员 -> 编辑个人信息

