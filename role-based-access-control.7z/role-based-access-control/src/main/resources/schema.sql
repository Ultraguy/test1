CREATE TABLE user
(
    user_id   INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password  VARCHAR(255) NOT NULL
);

CREATE TABLE role
(
    role_id   INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(255) NOT NULL
);

CREATE TABLE permission
(
    permission_id   INT AUTO_INCREMENT PRIMARY KEY,
    permission_name VARCHAR(255) NOT NULL,
    page_url        VARCHAR(255) NOT NULL -- 关联页面URL
);


CREATE TABLE user_role
(
    user_id INT NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user (user_id),
    FOREIGN KEY (role_id) REFERENCES role (role_id),
    PRIMARY KEY (user_id, role_id) -- 确保一个用户不能有重复的角色
);


CREATE TABLE role_permission
(
    role_id       INT NOT NULL,
    permission_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES role (role_id),
    FOREIGN KEY (permission_id) REFERENCES permission (permission_id),
    PRIMARY KEY (role_id, permission_id) -- 确保一个角色不能有重复的权限
);

