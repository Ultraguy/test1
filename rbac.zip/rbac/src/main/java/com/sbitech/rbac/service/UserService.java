package com.sbitech.rbac.service;


import com.sbitech.rbac.model.User;


public interface UserService {

    User findByUsername(String username);

    boolean verifyPassword(String plainPassword, String hashedPassword);
}
