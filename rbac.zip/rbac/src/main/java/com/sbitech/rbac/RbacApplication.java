package com.sbitech.rbac;

public class RbacApplication {
}
