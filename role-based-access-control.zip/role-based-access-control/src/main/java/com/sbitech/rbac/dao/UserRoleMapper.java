package com.sbitech.rbac.dao;

import com.sbitech.rbac.model.UserRole;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserRoleMapper {
    @Insert("INSERT INTO user_role (user_id, role_id) VALUES (#{userId}, #{roleId})")
    void insert(int userId, int roleId);

    @Delete("DELETE FROM user_role WHERE role_id = #{roleId} and user_id = #{userId}")
    void delete(int userId, int roleId);
}
