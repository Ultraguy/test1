package com.sbitech.rbac.service;

public interface UserRoleService {
    void assignRoleToUser(int userId, int roleId);

    void removeRoleFromUser(int userId, int roleId);


}
