package com.sbitech.rbac.service.impl;

import com.sbitech.rbac.dao.*;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.User;
import com.sbitech.rbac.service.UserRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class UserRoleServiceImpl implements UserRoleService {

    @Autowired
    private UserRoleMapper userRoleMapper;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private UserMapper userMapper;

    @Override
    public void assignRoleToUser(int userId, int roleId) {
        User user = userMapper.findById(userId);
        Role role = roleMapper.findById(roleId);
        if (Objects.isNull(user) || Objects.isNull(role))
            return;
        userRoleMapper.insert(userId, roleId);
    }

    @Override
    public void removeRoleFromUser(int userId, int roleId) {
        userRoleMapper.delete(userId, roleId);
    }
}
