package com.sbitech.rbac.service;

public interface RolePermissionService {
    void assignPermissionToRole(int roleId, int permissionId);

    void removePermissionFromRole(int roleId, int permissionId);
}
