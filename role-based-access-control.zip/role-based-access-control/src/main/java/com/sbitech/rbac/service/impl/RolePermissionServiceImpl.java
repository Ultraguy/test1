package com.sbitech.rbac.service.impl;

import com.sbitech.rbac.dao.PermissionMapper;
import com.sbitech.rbac.dao.RoleMapper;
import com.sbitech.rbac.dao.RolePermissionMapper;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.service.RolePermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class RolePermissionServiceImpl implements RolePermissionService {
    @Autowired
    private RolePermissionMapper rolePermissionMapper;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private PermissionMapper permissionMapper;

    public void assignPermissionToRole(int roleId, int permissionId) {
        Role role = roleMapper.findById(roleId);
        Permission permission = permissionMapper.findById(permissionId);
        if (Objects.isNull(role) || Objects.isNull(permission))
            return;
        rolePermissionMapper.insert(roleId, permissionId);
    }

    public void removePermissionFromRole(int roleId, int permissionId) {

        rolePermissionMapper.delete(roleId, permissionId);
    }
}
