package com.sbitech.rbac.controller;


import com.sbitech.rbac.dto.ApiResponse;
import com.sbitech.rbac.dto.UserDTO;
import com.sbitech.rbac.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class LoginController {
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ApiResponse login(UserDTO request) {
        return userService.login(request);
    }
}
