package com.sbitech.rbac.service;

import com.sbitech.rbac.dto.ApiResponse;
import com.sbitech.rbac.dto.UserDTO;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.User;
import com.sbitech.rbac.model.UserInfo;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface UserService {

    List<UserInfo> getAllUsers();

    User getUserById(int userId) ;

    ApiResponse login(UserDTO request);

    User findUserByUsername(String username);

    void createUser(UserDTO user) ;

    void updateUser(User user) ;

    void deleteUser(int userId) ;

    List<Permission> getAllPermissionsFromUser(User user);
}
