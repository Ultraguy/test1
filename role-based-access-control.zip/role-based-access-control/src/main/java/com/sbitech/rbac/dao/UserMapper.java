package com.sbitech.rbac.dao;

import com.sbitech.rbac.dto.UserDTO;
import com.sbitech.rbac.model.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM user")
    List<User> getAllUsers();

    @Select("SELECT * FROM user WHERE user_id = #{userId}")
    User findById(int userId);

    @Select("SELECT * FROM user WHERE username = #{username}")
    User findByUsername(String username);

    @Insert("INSERT INTO user (username, password) VALUES (#{username}, #{password})")
    void insert(UserDTO user);

    @Update("UPDATE user SET username = #{username}, password = #{password} WHERE user_id = #{userId}")
    void update(User user);

    @Delete("DELETE FROM user WHERE user_id = #{userId}")
    void delete(int userId);
}
