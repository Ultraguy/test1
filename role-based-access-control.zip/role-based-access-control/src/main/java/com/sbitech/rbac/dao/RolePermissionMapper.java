package com.sbitech.rbac.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RolePermissionMapper {
    @Insert("INSERT INTO role_permission (role_id, permission_id) VALUES (#{roleId}, #{permissionId})")
    void insert(int roleId, int permissionId);

    @Delete("DELETE FROM role_permission WHERE role_id = #{roleId} and permission_id = #{permissionId}")
    void delete(int roleId, int permissionId);
}
