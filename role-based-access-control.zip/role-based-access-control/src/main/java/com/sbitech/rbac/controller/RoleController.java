package com.sbitech.rbac.controller;

import com.sbitech.rbac.dto.PermissionDTO;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.RoleInfo;
import com.sbitech.rbac.service.RolePermissionService;
import com.sbitech.rbac.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/roles")
public class RoleController {

    @Autowired
    private RolePermissionService rolePermissionService;
    @Autowired
    private RoleService roleService;

    @PostMapping("/assign")
    public ResponseEntity<?> assignPermissionToRole(@RequestParam int roleId, @RequestParam int permissionId) {
        try {
            rolePermissionService.assignPermissionToRole(roleId, permissionId);
            return ResponseEntity.ok().body("成功分配权限");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/remove")
    public ResponseEntity<?> removePermissionFromRole(@RequestParam int roleId, @RequestParam int permissionId) {
        try {
            rolePermissionService.removePermissionFromRole(roleId, permissionId);
            return ResponseEntity.ok().body("成功移除权限");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public List<RoleInfo> getAllRoles() {
        return roleService.getAllRoles();
    }

    @PostMapping
    public ResponseEntity<Void> createPermission(Role role) {
        roleService.insert(role);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePermission(@PathVariable int id) {
        roleService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
