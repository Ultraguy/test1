package com.sbitech.rbac.dao;

import com.sbitech.rbac.dto.PermissionDTO;
import com.sbitech.rbac.model.Permission;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RoleMapper {
    @Select("SELECT * FROM permission")
    List<Role> getAllPermissions();

    @Select("SELECT * FROM permission WHERE permission_name like '%#{username}%'")
    Permission findByPermissionName(String name);

    @Insert("INSERT INTO permission (permission_name, page_url) VALUES (#{permissionName}, #{pageUrl})")
    void insert(PermissionDTO permission);

    @Delete("DELETE FROM permission WHERE permission_id = #{id}")
    void delete(int id);
}
