package com.sbitech.rbac.service.impl;

import com.sbitech.rbac.model.User;
import com.sbitech.rbac.dao.UserMapper;
import com.sbitech.rbac.dto.UserDTO;
import com.sbitech.rbac.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    public ResponseEntity<String> login(UserDTO request) {
        User user = userMapper.findByUsername(request.getUsername());
        if (user != null && request.getPassword().equals(user.getPassword())) {
            return new ResponseEntity<String>("登录成功",HttpStatus.OK);
        } else {
            return new ResponseEntity<>("用户名或密码有误", HttpStatus.UNAUTHORIZED);
        }
    }

    @Override
    public List<User> getAllUsers() {
        return userMapper.getAllUsers();
    }

    @Override
    public User getUserById(int userId) {
        return userMapper.findById(userId);
    }

    @Override
    public User findUserByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    @Override
    public void createUser(UserDTO user) {
        userMapper.insert(user);
    }

    @Override
    public void updateUser(User user) {
        userMapper.update(user);
    }

    @Override
    public void deleteUser(int userId) {
        userMapper.delete(userId);
    }

}
