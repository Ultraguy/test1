package com.sbitech.rbac.service.impl;

import com.sbitech.rbac.dao.RoleMapper;
import com.sbitech.rbac.dto.ApiResponse;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.User;
import com.sbitech.rbac.dao.UserMapper;
import com.sbitech.rbac.dto.UserDTO;
import com.sbitech.rbac.model.UserInfo;
import com.sbitech.rbac.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private RoleMapper roleMapper;

    public ApiResponse login(UserDTO request) {
        User user = userMapper.findByUsername(request.getUsername());
        if (user != null && request.getPassword().equals(user.getPassword())) {
            return new ApiResponse(HttpStatus.OK.value(), "登录成功");
        } else {
            return new ApiResponse(HttpStatus.UNAUTHORIZED.value(), "用户名或密码有误");
        }
    }

    @Override
    public List<Permission> getAllPermissionsFromUser(User user){
        List<Permission> pl = new ArrayList<>();
        for (Role role: userMapper.getRoleByUser(user)) {
            pl.addAll(roleMapper.getPermissionsByRole(role));
        }
        return pl.stream().distinct().toList();
    }

    @Override
    public List<UserInfo> getAllUsers() {
        return userMapper.getAllUsers();
    }

    @Override
    public User getUserById(int userId) {
        return userMapper.findById(userId);
    }

    @Override
    public User findUserByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    @Override
    public void createUser(UserDTO user) {
        userMapper.insert(user);
    }

    @Override
    public void updateUser(User user) {
        userMapper.update(user);
    }

    @Override
    public void deleteUser(int userId) {
        userMapper.delete(userId);
    }

}
