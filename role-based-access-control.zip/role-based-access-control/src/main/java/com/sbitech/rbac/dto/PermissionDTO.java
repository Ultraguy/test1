package com.sbitech.rbac.dto;

public class PermissionDTO {
    private String permissionName;
    private String pageUrl;

    public PermissionDTO() {
    }

    public PermissionDTO(int permissionId, String permissionName, String pageUrl) {
        this.permissionName = permissionName;
        this.pageUrl = pageUrl;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public String getPageUrl() {
        return pageUrl;
    }

    public void setPageUrl(String pageUrl) {
        this.pageUrl = pageUrl;
    }
}
