package com.sbitech.rbac.service.impl;

import com.sbitech.rbac.dao.PermissionMapper;
import com.sbitech.rbac.dao.RoleMapper;
import com.sbitech.rbac.dao.UserMapper;
import com.sbitech.rbac.dto.PermissionDTO;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.User;
import com.sbitech.rbac.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PermissionServiceImpl implements PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;

    @Override
    public List<Permission> getAllPermissions() {
        return permissionMapper.getAllPermissions();
    }

    @Override
    public Permission findByPermissionName(String name) {
        return permissionMapper.findByPermissionName(name);
    }

    @Override
    public void createPermission(PermissionDTO permission) {
        permissionMapper.insert(permission);
    }

    @Override
    public void deletePermission(int id) {
        permissionMapper.delete(id);
    }
}
