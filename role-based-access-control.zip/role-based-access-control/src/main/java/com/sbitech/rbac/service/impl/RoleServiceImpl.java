package com.sbitech.rbac.service.impl;

import com.sbitech.rbac.dao.RoleMapper;
import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.RoleInfo;
import com.sbitech.rbac.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleMapper roleMapper;

    @Override
    public List<RoleInfo> getAllRoles() {
        return roleMapper.getAllRoles();
    }

    @Override
    public void insert(Role role) {
        roleMapper.insert(role);
    }

    @Override
    public void delete(int id) {
        roleMapper.delete(id);
    }
}
