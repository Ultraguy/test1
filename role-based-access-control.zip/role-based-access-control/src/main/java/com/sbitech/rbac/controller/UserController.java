package com.sbitech.rbac.controller;

import com.sbitech.rbac.dto.UserDTO;
import com.sbitech.rbac.model.Permission;
import com.sbitech.rbac.model.User;
import com.sbitech.rbac.model.UserInfo;
import com.sbitech.rbac.service.UserRoleService;
import com.sbitech.rbac.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRoleService userRoleService;

    @PostMapping("/assign")
    public ResponseEntity<?> assignRoleToUser(@RequestParam int userId, @RequestParam int roleId) {
        try {
            userRoleService.assignRoleToUser(userId, roleId);
            return ResponseEntity.ok().body("成功分配角色");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/remove")
    public ResponseEntity<?> removeRoleFromUser(@RequestParam int userId, @RequestParam int roleId) {
        try {
            userRoleService.removeRoleFromUser(userId, roleId);
            return ResponseEntity.ok().body("成功移除角色");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public List<UserInfo> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/permissions")
    public List<Permission> getAllPermissionsFromUser(User user) {
        return userService.getAllPermissionsFromUser(user);
    }


    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable int id) {
        User user = userService.getUserById(id);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @PostMapping
    public ResponseEntity<Void> createUser(UserDTO user) {
        userService.createUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateUser(@PathVariable int id, User user) {
        user.setUserId(id);
        userService.updateUser(user);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable int id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }


}
