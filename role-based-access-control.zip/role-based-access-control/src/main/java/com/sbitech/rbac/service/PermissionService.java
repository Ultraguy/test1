package com.sbitech.rbac.service;

import com.sbitech.rbac.dto.PermissionDTO;
import com.sbitech.rbac.model.Permission;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface PermissionService {
    List<Permission> getAllPermissions();

    Permission findByPermissionName(String name);

    void createPermission(PermissionDTO permission) ;

    void deletePermission(int userId) ;
}
