package com.sbitech.rbac.service;


import com.sbitech.rbac.model.Role;
import com.sbitech.rbac.model.RoleInfo;
import com.sbitech.rbac.model.User;

import java.util.List;

public interface RoleService {
    List<RoleInfo> getAllRoles();

    void insert(Role role);

    void delete(int id);
}
