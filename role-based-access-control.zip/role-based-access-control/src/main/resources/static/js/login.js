document.addEventListener('DOMContentLoaded', () => {
    const loginButton = document.getElementById('loginButton');
    loginButton.addEventListener('click', async () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorMessage = document.getElementById('error-message');

        // 清空错误消息
        errorMessage.textContent = '';

        // 验证输入
        if (!username || !password) {
            errorMessage.textContent = '用户名和密码不能为空';
            return;
        }

        try {
            // 请求后端
            const response = await fetch('http://localhost:8080/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            // 解析响应
            const data = await response.json();

            if (response.ok) {
                // 登录成功，处理响应
                // 例如：保存 token 或跳转页面
                console.log('登录成功', data);
                // 跳转到首页或其他页面
                window.location.href = '/dashboard';
            } else {
                // 登录失败，显示错误消息
                errorMessage.textContent = data.message || '登录失败，请重试';
            }
        } catch (error) {
            console.error('登录错误', error);
            errorMessage.textContent = '登录过程中发生错误，请稍后再试';
        }
    });
});
